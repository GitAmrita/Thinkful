package com.vogella.android.flyer;

import android.os.Parcelable;

/**
 * Created by amritachowdhury on 8/10/16.
 */
public enum Week {
    MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY
};
