package com.thinkful.notes;

/**
 * Created by amritachowdhury on 7/23/16.
 */
public class NoteListItem {
    private String text;

    public NoteListItem(String text) {
        this.text = text;
    }

    public String getText() {
        return this.text;
    }
}
