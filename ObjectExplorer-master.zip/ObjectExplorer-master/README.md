# ObjectExplorer
Android sample application for Unit 2 in Thinkful Android curriculum


===============

This is the source code for the Thinkful Android Object Explorer App for Unit 2. 

This app is meant for you to easily write code and see the results of it on the screen of the Android emulator.
You call this.log(message), from within the MainActivity class, where message is a string you want to have printed to the emulator screen.

If you don't see the messages printed on the screen, press the Go button near the top right of the emulator screen.
